package Practice.fifth ;

import java.util.Scanner;

public class pascal{
    // in the pascal question they can give us the row no and col no we need to find the element 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for(int i=0;i<n;i++){//for rows
            for(int j=0;j<=n-i;j++){// for spaces
                System.out.print(" ");

            }
            int number =1;
            for(int k=0;k<=i;k++){
                System.out.print(number+" ");
                number=number * (i-k)/(k+1);


            }
            System.out.println();
            

        }
    }


}
 


