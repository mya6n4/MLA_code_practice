package Practice.Third; 
// // 14. Toggle Case of Each Character
// // // Convert uppercase letters to lowercase and vice versa
// // this is the solution using the in built method 
// import Practice.second.secondlargest;
// public class upperlowerstring {
//     public static void main(String[] args) {
//         StringBuffer str = new StringBuffer("Palak");
//         CoverUpplow(str);
        
import java.util.Scanner;

//     }
    

// public static void CoverUpplow(StringBuffer str){
//     int len = str.length();
//     for (int i=0;i<len;i++){
//         Character c = str.charAt(i);
//         if(Character.isLowerCase(c)){
//             str.setCharAt(i,Character.toUpperCase(c));

//         }
//         else{
//             str.setCharAt(i,Character.toLowerCase(c));
//         }
//     }
//     System.out.println(str);
// }

// }
// ==============================without using the inbuilt method=====================================================================================
import Practice.second.secondlargest;
public class upperlowerstring {
    public static void main(String[] args) {
        String result = "";
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        for(int i = 0;i<str.length();i++){
            char ch = str.charAt(i);
            // for checking the charcter is in upper case
            if(ch>='A'&& ch<='Z'){
                result=result+(char)(ch+32);

            }
            else if(ch>='a'&& ch<='z'){
                result= result+(char)(ch-32);

            }
            else
            {
                result+= ch;

            }
        }
        System.out.println(" toogle case:"+result);


    }

}