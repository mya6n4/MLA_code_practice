package Practice.Third;

public class countvowel {
    public static void main(String[] args) {
        int count_vowel =0;
        int count_consonent = 0;
        String variable ="pAlak";
        
        String vowels = "AEIOUaeiou";
        for (int i = 0 ; i<variable.length();i++){
            char ch = variable.charAt(i);
//vowels → it is the string "AEIOUaeiou" (all vowels).

// indexOf(ch) → checks if the character ch is inside the string vowels.

// If it is found, it gives its position number (like 0, 1, 2...).

// If it is not found, it gives -1.

// != -1 → means “not equal to -1” → so the letter is found → that means it's a vowel.
//        🧩 First, understand this:

// vowels.indexOf(ch) → this is a built-in Java method.
// It searches for the character ch inside the string vowels.

// Now remember this rule:

// If the character is found, it returns the position number (index).

// If the character is NOT found, it returns -1. 
if(vowels.indexOf(ch)==-1){// u can use like this or vowel.indexof(ch !=-1); this is also correct but ghuma ke bol diya h h same hi baki sara uppar h concept indexof kya karta sab h
            count_consonent+=1;

        }
        else{
            count_vowel+=1;
        }
        }
        System.out.println(count_vowel);
        System.out.println(count_consonent);
    }
    
}
