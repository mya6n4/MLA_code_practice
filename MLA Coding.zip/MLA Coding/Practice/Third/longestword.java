// package Practice.Third;

// import java.util.Scanner;

// public class longestword {
//     public static void main(String[] args) {
//         char ch ;

//         Scanner sc = new Scanner(System.in);
//         String ls ="";
//         String s1="";
//         String s = sc.nextLine();
//         s = s+" ";
//         int l = s.length();
       
//         for(int i = 0; i<l;i++){
//             ch = s.charAt(i);
        
//             if(ch!= ' '){
//                 s1=s1+ch;
//             }
//             else {  // when space found, check the length
//                 if (s1.length() > ls.length()) {
//                     ls = s1;  // update longest word
//                 }
//                 s1 = "";  // reset for next word
//             }
//         }
//         System.out.println("the largest word :" +ls);
//         System.out.println(ls.length());       
            
//     }

    
// }
// ====================================================================================================================
// second way to do the program 
package Practice.Third;
// import java util.Scanner;
public class longestword{
    public static void main(String[] args) {
        String sentence = "to is sunday";
        String longestWrod =" ";
        String[] word=sentence.split(" ");//split is use to split the word 
        for(int i = 0;i<word.length;i++){
            if (word[i].length()>longestWrod.length()){
                longestWrod = word[i];
            }
        }
        System.out.println(longestWrod);
        System.out.println(longestWrod.length());
    }
}