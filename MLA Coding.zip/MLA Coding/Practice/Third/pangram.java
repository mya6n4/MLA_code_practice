package Practice.Third;
import java.util.*;
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// // in the string if you are able to find all the charcter a to z so it is a pangram 
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import java.util.HashSet;
public class pangram {
    public static void main(String[] args) {
        String sentence = "thequickbrownfoxjumpsoverthelazydog".toLowerCase();
        
        Set <Character> alphabetsSet = new HashSet<>();

        // add the 
        for(int i ='a';i<='z';i++){
            alphabetsSet.add((char) i);
        }

        for(int i = 0;i<sentence.length();i++){
            alphabetsSet.remove(sentence.charAt(i));
            if(alphabetsSet.isEmpty()){
                System.out.println("it is a panagram");
                return ;
            }
        }
        System.out.println("it is not a panagram");

    }
    
}
