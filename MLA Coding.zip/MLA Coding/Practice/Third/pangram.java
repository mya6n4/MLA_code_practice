package Practice.Third;

public class pangram {
    
}
