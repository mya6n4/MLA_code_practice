package Practice.fourth;

import java.util.Scanner;

public class DecimalToBinary {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a decimal number: ");
        int decimal = sc.nextInt();

        int binary[] = new int[40];
        int index = 0;

        while (decimal > 0) {
            binary[index++] = decimal % 2; // store remainder (0 or 1)
            decimal = decimal / 2;         // divide number by 2
        }

        System.out.print("Binary number: ");
        for (int i = index - 1; i >= 0; i--) {
            System.out.print(binary[i]);  // print in reverse order
        }
    }
}
