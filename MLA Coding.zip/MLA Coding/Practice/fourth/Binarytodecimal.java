package Practice.fourth;

import java.util.Scanner;

public class Binarytodecimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a binary number: ");
        int binary = sc.nextInt();  // e.g., 1010

        int decimal = 0;
        int power = 0;

        while (binary > 0) {
            int lastDigit = binary % 10;                // extract rightmost binary digit
            decimal += lastDigit * Math.pow(2, power);  // multiply by 2^position
            binary = binary / 10;                       // remove last digit
            power++;                                    // increase position
        }

        System.out.println("The binary is converted into decimal: " + decimal);
    }
}
