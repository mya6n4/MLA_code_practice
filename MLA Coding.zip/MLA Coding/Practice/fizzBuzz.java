package Practice;

// 1. FizzBuzz Variation
// Print numbers from 1 to n, but replace multiples of 3 with "Fizz", 5 with "Buzz", and both with 
// "FizzBuzz".

public class fizzBuzz {
    public static void main(String[] args) {
        int n = 20;
        for (int i = 1; i <= n; i++) {
            if (i % 3 == 0 && i % 5 == 0)
                System.out.println("FizzBuzz");
            else if (i % 3 == 0)
                System.out.println("Fizz");
            else if (i % 5 == 0)
                System.out.println("Buzz");
            else
                System.out.println(i);
        }
    }
}


