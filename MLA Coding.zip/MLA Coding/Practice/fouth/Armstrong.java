package Practice.fouth;

import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum=0;
        int temp=n;
//        ==================Variable	Purpose
// n	Used for calculation, gets reduced to 0
// temp	Stores the original number to compare later==================================================================================
        while(n>0){
            int lastdigit = n%10;
            sum+=lastdigit*lastdigit*lastdigit;
            n=n/10;
        }
        if (temp==sum){
            System.out.println("it is a aramstrong no");
        }
        else{
            System.out.println("not a armstrong no");
        }
        System.out.println();
        }
    }
    

