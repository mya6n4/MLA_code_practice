package Practice.first;

// 5. Find GCD and LCM of Two Numbers
import java.util.Scanner;

// Use loops and conditionals to compute both GCD and LCM.
public class GCD_LCM {

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;

    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter first number");
        int a = sc.nextInt();
        System.out.print("enter second number");
        int b = sc.nextInt();

        int gcdvalue = gcd(a, b);
        int lcm = (a * b) / gcdvalue;

        System.out.println(lcm);
        System.out.print(gcdvalue);

    }

}
