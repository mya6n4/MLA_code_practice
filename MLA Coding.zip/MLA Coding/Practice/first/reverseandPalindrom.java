package Practice.first;
// Reverse a Number and Check Palindrome
// Reverse an integer and check if it’s a palindrome.

import java.util.Scanner;

public class reverseandPalindrom {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter the no");
    int n= sc.nextInt();
    int revno = 0;
      int temp = n;
    while(n>0){
      
        int lastdigit=n%10;
        revno=n*10+lastdigit;
        n=n/10;  
    }
    temp=revno;
    if(revno==temp){
        System.out.println("it is the palindrome");
        }
        else{
            System.out.println("it is not ao palindrome");
        
        }

    
    }
        
    }
    

