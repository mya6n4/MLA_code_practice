package Practice;

// 3. Sum of Digits Until Single Digit
// Keep summing the digits of a number until a single-digit result is obtained.

import java.util.Scanner;

public class sumDigit {
    public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter a number: ");
    int n = sc.nextInt();
    while(n>=10){
    int sum = 0 ;

    while(n> 0){
    int lastdigit = n%10;
    sum += lastdigit;
    n = n/10;
    }
    n=sum;
    
}
System.out.println("Final singal digit sum:"+n);
}
    

}

