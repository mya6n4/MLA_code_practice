package Practice.second;

public class Rotate_array {
    public static void main(String args[]){
        int n []={1,2,3,4};
        int start = 0;
        int end = n.length-1;

        while (start<end){
            
        
                int temp = n[start];
                n[start]=n[end];
                n[end]=temp;
                start++;
                end--;


            }

         System.out.print("Reversed array: ");
        for (int i = 0; i < n.length; i++) {
            System.out.print(n[i] + " ");

            
        }
    }
    
}
