package Practice.second;

public class secondlargest{
    public static void main(String[] args) {
        int arr[] = {1, 2, 4, 7, 7, 5};

        // Step 1: Find the largest number
        int largest = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > largest) {
                largest = arr[i];
            }
        }

        // Step 2: Find the second largest number
        int secondLargest = Integer.MIN_VALUE; // better than -1 (works with negatives too)
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != largest && arr[i] > secondLargest) {
                secondLargest = arr[i];
            }
        }

        System.out.println("Largest: " + largest);
        System.out.println("Second Largest: " + secondLargest);
    }
}
