package Practice.first;

// 2. Prime Number Checker
// Check if a given number is prime. If not, list its factors.

import java.util.Scanner;

public class PrimeNumberChecker{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int count = 0;

        for(int i = 1;i<=n;i++){
            if(n%i==0){
                count++;
            }
        }
            if(count == 2){
                System.out.println("prime no ");
            }
            else{
                System.out.println("not a prime no ");
                // to print the all the divisors
                for(int i=1;i<=n;i++){
                    if(n%i==0){
                        System.out.print(" "+i);
                    }
                }
                
            
            }

        }

        
    }
//     public class PrimeNumberChecker {
//     public static void main(String[] args) {

//         int n = 28; // The number to check

//         // Step 1: Numbers less than or equal to 1 are not prime
//         if (n <= 1) {
//             System.out.println(n + " is not a prime number.");
//             return; // stop execution here
//         }

//         boolean isPrime = true; // assume the number is prime

//         System.out.print("Factors of " + n + " are: ");

//         // Step 2: Find and print all factors of n
//         for (int i = 1; i <= n; i++) {
//             if (n % i == 0) { // checks divisibility
//                 System.out.print(i + " ");

//                 // Step 3: If there’s any factor other than 1 and n → not prime
//                 if (i != 1 && i != n) {
//                     isPrime = false;
//                 }
//             }
//         }

//         System.out.println(); // new line for better output formatting

//         // Step 4: Final check
//         if (isPrime)
//             System.out.println(n + " is a prime number.");
//         else
//             System.out.println(n + " is not a prime number.");
//     }
// }


