package Practice.first;

// 5. Find GCD and LCM of Two Numbers
// Use loops and conditionals to compute both GCD and LCM.
public class GCD_LCM {
    
}
