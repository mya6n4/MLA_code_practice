package Practice.second;

public class findMissing {
     public static void main(String[] args) {
        int nums[] = {1, 2, 4, 5, 6, 0};
        int sum = 0;

        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
        }

        int n = nums.length; // ✅ total numbers should be n = 7
        int expectedSum = n * (n + 1) / 2; // ✅ sum of 1 to 7 = 28

        int missing = expectedSum - sum;

        System.out.println("Missing number is: " + missing);
    }
    
    
}
