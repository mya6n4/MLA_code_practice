package Practice.second;



public class sortedarray {
    public static void main(String[] args) {
        int number[] = {1, 2, 3, 4, 5};

        boolean isAscending = true;
        boolean isDescending = true;

        for (int i = 0; i < number.length - 1; i++) {
            if (number[i] > number[i + 1]) {
                isAscending = false;  // Not ascending
            }
            if (number[i] < number[i + 1]) {
                isDescending = false; // Not descending
            }
        }

        if (isAscending) {
            System.out.println("Array is sorted in ascending order");
        } else if (isDescending) {
            System.out.println("Array is sorted in descending order");
        } else {
            System.out.println("Array is not sorted");
        }
    }
}
